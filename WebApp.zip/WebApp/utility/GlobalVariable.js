class GlobalVariable 
{	
	constructor()
	{	
		//World size
		this.WorldSize = 500;

		//For agent
		this.speed = 2;
	}
}


