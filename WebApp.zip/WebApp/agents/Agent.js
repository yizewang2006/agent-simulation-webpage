class Agent
{
	constructor()
	{
		//this.GlobalVariable = new GlobalVariable();
		this.speed = GlobalVariable.speed;
		this.heading_history = [];
		
	}

	createRandomAgent()
	{

	}
}